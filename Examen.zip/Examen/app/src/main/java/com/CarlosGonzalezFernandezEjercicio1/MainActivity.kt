package com.CarlosGonzalezFernandezEjercicio1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            App()
        }
    }
}

data class nombre(val name: String)

data class price(val price: Double)

data class imageUrl(val url: String)


@Preview(showBackground = true)
@Composable
fun App() {
    LazyColumn {
        item {
            Modifier
                .fillMaxSize()
                .height(40.dp)
        }
    }
}